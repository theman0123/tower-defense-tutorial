export default {
  inital: {
    enemySpeed: 1/100000,
    enemyHealth: 50
  },
  incremental: {
    enemySpeed: 5,
    enemyHealth: 50
  }
};
