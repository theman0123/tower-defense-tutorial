import 'phaser';

export default class UIScene extends Phaser.Scene {
  constructor() {
    super('UI');
  }

  create() {
  }
}
